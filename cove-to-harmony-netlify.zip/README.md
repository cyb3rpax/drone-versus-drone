# Deploy Cove ⇄ Harmony on Netlify

## Option A — Live in 5 minutes (drag & drop, local accounts)
1. Go to https://netlify.com → Sign up (free, email or Google).
2. Once logged in, go to https://app.netlify.com/drop
3. Drag this whole `netlify-deploy` folder from Finder onto the dashed box.
4. Wait ~30 seconds → "Your site is live" with a link like wonderful-otter-123.netlify.app.
5. Click it — marketing page live, Play buttons work. Accounts run per-browser
   in this mode (drag-and-drop can't install the API's dependency).
6. Optional: Site configuration → Change site name → e.g. cove-to-harmony.netlify.app

## Option B — Real cloud accounts (~15 min, via GitHub)
Registration/login then works for everyone, saves stored in Netlify Blobs.

1. Make a free account at https://github.com
2. Click the "+" (top right) → New repository → name it cove-to-harmony →
   Public → Create repository.
3. On the repo page click "uploading an existing file", then drag the CONTENTS
   of this folder into the box: index.html, cove-to-harmony.html, netlify.toml,
   package.json, README.md, and the netlify folder (all in one drag —
   Chrome keeps the folder structure).
4. Click the green "Commit changes" button.
5. In Netlify: Add new site → Import an existing project → GitHub →
   authorize → pick the cove-to-harmony repo.
6. Leave Build command empty; Publish directory "." → Deploy.
7. Wait 1–2 minutes → your URL is live with working accounts.

Troubleshooting:
- Play button 404 → index.html must be at the TOP level of the repo,
  not inside a subfolder.
- "Server unreachable" on sign-up → check the Deploys log bundled a
  function named "api".

Either way, `/api/register`, `/api/login`, `/api/me` and `/api/save` are served by
`netlify/functions/api.mjs`, with accounts stored in Netlify Blobs. Registration,
login, and cloud saves then work for anyone who visits your site.

## What's in here
- `index.html` — the marketing page (front door)
- `cove-to-harmony.html` — the game (linked from every PLAY button)
- `netlify/functions/api.mjs` — the accounts API (register/login/me/save)
- `netlify.toml`, `package.json` — Netlify config & the Blobs dependency

The game auto-detects: if the API exists it uses real accounts; if not
(Option A), it falls back to in-browser accounts automatically.
